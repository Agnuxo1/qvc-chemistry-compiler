# Candidate05: identical phase with two fewer controlled swaps

Copyright 2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0. Credits: Opus and Astra.

The parent authorized this complete gate before construction in
`PAPER_GATE_RECEIPT_016_VARIANT.json`, SHA-256
`141d51af466cea914cc9c318e09c34558b7c23c6247fbf5e87c9ea9f1efa7cbe`.

Inherit candidate04's native-proved arithmetic and its exact angles, unchanged.
The full quantize50 receipt is pinned: minimum margin124,372,027 in2^-64 turns,
rotation charge238.04838838550535. Do not repeat that scan. The two subsequent
angle alternatives are both more expensive and are excluded from this build.

Change only the five reflection centres to(-1,-3,-7,-1,-2), and omit only
the controlled swap at stage0 between word positions0 and26 in each direction.
The common-offset finite certificate proves all11 final permutations identical
and both omitted gates act on constant1 endpoints. The route costs128 rather
than130 Toffolis; other phase work remains16. No preparation, phase repair,
measurement, owner or angle is changed.

Complete gate: Q49, both coefficient preparation peaks49, expected Toffolis
1560.5,4T,34R, complete expected equivalents1799.5483883855054 and cost
88177.87103088977. Phase owners remain43 data+2 ones+2 retained controls+2
transient helpers. All existing correction obligations remain included.

The new generator must check a route-only structural contract against pinned
candidate04 native text. Outside the two exact route blocks every operation,
argument, condition, HMR event and phase must match. Inside each route block,
all non-CSWAP operations must match; the old and new CSWAP lists must equal
their respective five reflection matchings, with exactly the authorized
stage0 omission in the new list. Require the complete native expected count
1560.5/4T/34R and peak49 before saving.

Run a fresh four-seed native sample and complete original-domain/all-HMR
proof against the unchanged pinned50-unit oracle and checker. The new wrapper
asserts modulus2^50 and exact expected count1560.5; it reuses the pinned
candidate04 proof functions, not their old candidate04 main/count check.
Require the full oracle phase digest to equal the original quantize receipt.
The original four64-shot official salts remain a separate qualification gate.

Preserve candidates01–04. Only the parent shared strict guard runs the new
serial batch, under the inherited512MiB hard address-space limit. Stop on any
failure, split symbolic representation limits, never relax phase/reset/HMR
or original tolerance checks. No submission is authorized.
