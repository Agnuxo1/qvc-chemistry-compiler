# Resume candidate05

Copyright 2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0. Credits: Opus and Astra.

Authorized paper gate: `narrow/PAPER_GATE_RECEIPT_016_VARIANT.json`, SHA
141d51af466cea914cc9c318e09c34558b7c23c6247fbf5e87c9ea9f1efa7cbe.
Q49, expected1560.5Toff,4T,34R, exact margin124372027 units64,
rotation charge238.04838838550535, complete expected cost88177.87103088977.
No native candidate05 execution has occurred at this source handoff.

Parent shared strict guard command:

```
/usr/bin/python3.13 narrow/native/candidate05/run_batch.py --full-proof
```

The unchanged candidate04 angle receipt and all of its sources are pinned.
Do not repeat its full accuracy scan. Candidate05 changes only the route
centres to(-1,-3,-7,-1,-2) and omits(stage0,0,26) forward and inverse. The
finite proof of that exact identity is pinned. Both coefficient preparations
and every phase correction are included and unchanged.

`generate.py` compares against candidate04 native text. It records exact
route intervals during emission, requires all instructions outside them and
all non-CSWAP operations inside them to match, and validates both old/new
CSWAP operand lists against the authorized matching definitions. All34
angles and physical targets must match04 exactly. Expected count must be
1560.5/4T/34R at49 qubits before the artifact is saved.

`prove50.py` supplies a new candidate05 wrapper. It imports the unchanged
candidate04 checker functions and oracle through explicit source pins, uses
its own1560.5 build assertion, and executes fresh50-unit positive/negative
tests,4×8192 native shots,1024-input diagnostic, and full3,133,452-input/all-HMR
proof. The full expected-phase digest must match the pinned quantize receipt.
No reset, phase, input, scratch or HMR check is dropped. The candidate04 main
function and its1562.5 count assertion are not invoked.

The new output files belong only to this directory. Preserve candidates01–04.
After the fresh native batch passes, parent runs all four original official
salts with unchanged checks and tolerance. Native proof is not official
qualification. No submissions.
