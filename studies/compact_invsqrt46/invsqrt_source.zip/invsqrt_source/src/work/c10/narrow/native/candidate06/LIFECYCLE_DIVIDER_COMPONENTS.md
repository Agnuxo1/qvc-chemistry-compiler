# Candidate06 lifecycle and inverse-divider components

Copyright 2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0.
Credits: Opus and Astra.

These two isolated source files implement the parent-accepted complete Q48
gate in `PAPER_GATE_RECEIPT_018_VARIANT.json`. Prior candidates and research
certificates are unchanged. Syntax/static checks pass; this handoff does not
claim native emission, simulation, or official verification.

## Integration API

```python
divider = previous05.install()
divider_cleanup06.install(divider)
phase06.install(previous05)
v, h = lifecycle06.emit_body(
    builder, v, h, flags, tables06, divider, decoder06.decode_root,
    trace=trace,
)
```

`divider_cleanup06.install` validates the supplied module's frozen source,
binds it, and replaces only that process's `cleanup_divider` function. The
triangular u12 initializer and its exact cleanup remain installed by the
previous variant. Its inverse returns the **current** 15 product owners.

`lifecycle06.emit_body` keeps the prior call signature and returns the current
12 root and 10 residual owners. `lifecycle06.CUT_HOOK`, if set, is called as
`hook(label, builder, current_owner_dict)` at every recorded binding cut.
It adds explicit `second_H3_ready` and `second_a6_retired` cuts. `None` entries
in the root list denote genuinely retired values, never stale physical IDs.

The unchanged coefficient, seed, metadata and root-frame routines are invoked
through an isolated hash-pinned import of candidate01's lifecycle source.
Their original functions are not patched. The table and decoder modules are
passed explicitly; no global replacement of frozen modules is performed.

## New lifecycle ordering

The first loader returns its original A13/Hlow3 chart. The first coefficient,
seed, consuming product, and exact retirement of D13 keep their prior order.
The parent's divider then computes phase and returns current P15 owners.

Move the existing second R-frame operation before the second table load.
Pass the current seven high-root owners, with slot3 holding R. The table
adapter consumes raw slots0/1/2/4 into its mutable workspace. Immediately
after it returns, set root slots5/6/7/9 to `None` and record their deferred
raw-bit correction entries as `None`; their actual mixed signs already belong
to the shared table-debt ledger. No classical zero bits are fabricated.

Repay the first A6 snapshot on the newly loaded A6 before mutating it.
Prepare initial H3 while raw a5 and a6 are still live. Directly HMR-retire only
a6, record that real outcome, and then prepare H4 and the second coefficient.
The decoder later restores all five missing values, but directly corrects
only a6. R is unframed only after restoration. Final shared table cleanup
pays the four early mixed/input debts exactly once.

## Carry obligations and expected resources

At Q48 the complete lifecycle is **563 expected Toffolis**: loaders141,
cleanup9, coefficient123, seed17.5, R-frames4, metadata7, decoder21, and
product240.5. Product forward103 and inverse137.5 include every carry phase.

The product inverse enters with44 data owners, including Hlow3 and the old-A6
snapshot. Only rows0–7 own disposable input carries. Row8 isFalse; row9
aliases its live q and is never freed. Each owned carry is erased after the
first retained segment and regenerated conditionally for its boundary phase.
All eight regenerations, costing4 expected Toffolis, are included. Caller
cleanup is skipped only after the paired inverse reports release. Each
iteration returns to44 owners and checks its consumed, empty phase debt.

The divider core is **587.5 expected Toffolis**, including triangular u12
initialization/cleanup and all24 paired debts. Its13 feed rows use the same
documented dispose/regenerate interface, including6.5 conditional Toffolis.
Every inverse step restores43 current owners. Final u12 cleanup returns31:
root12, product15 and flags4. The returned P13/P14 handles are current.

Both callback families run only after the paired kernels restore their
source and dirty controls. The product's C8 parity may overlap the arithmetic
source, and q may be borrowed dirty; those exact restoration cuts were
audited in the parent-approved paper gate. Native all-HMR validation remains
required; resource assertions alone are not a functional proof.

## Parent verification

The parent owns the full source manifest, generator, component/native proof
wrappers, serial guarded batch, exhaustive original-domain/all-HMR proof, and
all four original official salts. The complete expected circuit remains
Q48 / 1,591 Toffolis / 4 T / 34 R, with the unchanged exact integer50 phase
model and margin124,372,027. Its predicted cost is87,842.32264250425.

`LIFECYCLE_DIVIDER_STATIC.json` pins these source files, their direct frozen
dependencies, the accepted gate and the two source-counter certificates.
