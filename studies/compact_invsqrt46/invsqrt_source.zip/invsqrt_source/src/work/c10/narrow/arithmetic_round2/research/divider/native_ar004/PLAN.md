# AR004 native history12 retirement component

Copyright2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0. Credits: Opus and Astra.

The parent accepted HISTORY12_COMPLETE_GATE.json before this native construction, with receipt DIVIDER_HISTORY12_PAPER_ACCEPTED.json. The exact complete divider is578 expected Toffolis,0T,0R,Q48, with270 forward and308 cleanup. The one-Toffoli sigma12 reconstruction is included. Every original forward instruction and the exact43-owner phase interface are unchanged. The phase endpoint is not installed, edited or executed by this arithmetic-only component proof.

The adapter binds only cleanup_divider. It verifies the frozen history12 kernel, its accepted AR003 final-row kernel, the accepted paper receipt and all input pins. It returns current logical P15 owners and replaces the consumed initializer-sign owner explicitly. Candidate01–09 and AR003 are immutable.

The native proof will emit the unchanged forward endpoint and complete arithmetic roundtrip, verify exact578/0/0 counts, compare the forward native text with the frozen AR003 forward text, and check the complete43-owner endpoint with an independent physical recurrence. Native simulation uses four seeds and16384 valid original-domain cases each, including two legal boundary inputs for every one of the4096 roots. The unsupported root4095/P counterexamples remain outside this domain and are preserved in the paper receipt.

The exact native instruction checker is an unchanged byte copy of the accepted31-input, modulo2 AR003 checker. Its three positive and four negative gate tests remain. Two new deliberately incorrect complete circuits must be rejected: one omits the retirement CZ phase, and one omits an original forward CarryDebt Z payment. No check or reset rule is relaxed. Every3,133,452 original input is encoded from the frozen model and proved against the emitted native text for all HMR transcripts, with explicit current input placement, zero scratch/reset and unchanged endpoint checks.

The checker accepts only the current arithmetic component's exact zero phase. The parent's complete circuit must separately retain the unchanged50-bit phase oracle and pass the original official verifier on all four salts. This component pass, if achieved, is not whole-circuit or official qualification.

All execution uses the new accepted strict shared guard,512MiB per-process address cap and no automatic retry. The source-ready command is sent to the parent before running. Parent coordination controls the shared execution slot.
