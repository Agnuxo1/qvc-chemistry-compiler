# Retire history12 only after the unchanged phase endpoint

Copyright 2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0. Credits: Opus and Astra.

This independent paper variant starts from the frozen accepted AR003 cleanup. It preserves the complete forward computation and all 43 endpoint owners through the phase call. Only afterward it uses the actual-model identity

`sigma12 = v11 XOR v10 XOR (v10 AND sigma13)`.

Measure history12 in X, pay its outcome with Z(v11), Z(v10), and CZ(v10,history13), then free that history owner and its classical outcome. This is zero Toffolis, T or rotations. The identity must hold on every original official input; it is not assumed on the entire unrestricted root/P cube.

Inverse rows35 through13 then run with42 data owners, obtaining one additional clean carry at the same Q48 cap. Every row keeps its existing arithmetic and feed-carry lifecycle, but its actual partition and every conditional regeneration must be recounted. The dirty inventory loses exactly the retired history owner; no unchanged dirty count is assumed.

After inverse j13, sigma13 lives in `token.u[13]`, not in an old history dictionary entry. Allocate one zero, reconstruct sigma12 with two CX and one CCX, and restore `history[12]`. The original initializer's sign owner has been reallocated, so update that logical owner in `initial_u`; never reuse its stale physical ID. Now the accepted AR003 j12/initializer cleanup executes at its unchanged43-owner entry.

The preparation and restoration of sigma12 therefore add exactly1 Toffoli; the complete source counter must show more than1 Toffoli saved across the earlier inverses. The entire candidate07 ledger is unchanged except this complete divider delta. No native construction is authorized until the all-original-input identity/phase proof and source-expanded Q48 gate are accepted by the parent.

The full-domain proof will generate the same pinned C/U0 model and pair-normalized inputs as the native circuit. It will calculate both physical first-row arithmetic and the independent signed recurrence, prove their equality, check the retirement and reconstruction identity, and explicitly test both possible fresh X-measurement outcomes. The exceptional unrestricted root4095/P-negative case must be preserved as a scope witness rather than hidden. Resource and all-CarryDebt ownership checks are distinct from measured native performance.

Frozen AR003, candidate07, phase, coefficients and all old receipts are immutable. New sources/results receive their own manifest. Jobs use the accepted round2 guard only.
