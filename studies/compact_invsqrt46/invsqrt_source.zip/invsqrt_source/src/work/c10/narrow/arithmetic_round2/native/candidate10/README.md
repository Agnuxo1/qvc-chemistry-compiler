# Candidate09: arithmetic composition

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This variant composes five separately proved arithmetic components around
the frozen candidate07 phase endpoint, coefficient loaders, phase cleanup,
angle table and independent exact phase oracle. It is a fallback while
further arithmetic studies continue. Candidate07 remains the qualified
release until a complete successor passes all four original official salts.

The complete paper price is 1,548.75 expected Toffolis, 4 T gates and 33 generic
rotations at Q48. Rotation charge is 230.84805946161188 equivalents, giving
modeled total cost 85,468.70685415737. Both preparation peaks and the phase
endpoint peak remain Q48. The original tolerance and exact minimum phase
margin 124,370,688 in units of 2^-64 are unchanged.

The selected arithmetic changes are normalization97.5→94.75, root198→192,
divider587.5→578, product240.5→228.5 and coefficient123→118. Every component
has a native proof and a parent acceptance receipt. This does not itself
prove their composition. The full original exact50 native checker, all
5 positive and 9 negative self-tests, all 3,133,452 original inputs, every
HMR transcript, original input restoration, zero scratch and zero-reset
checks must pass before any official verifier run.

The final official suite must use default batch256 (no batch argument in
the actual verifier command), salts default/1/2/3, two workers, the unchanged
640 MiB official envelope and the new authorized work-window guard. Report
the maximum over all four salts. No submissions are authorized or performed.

SOURCE_READY.json freezes this variant, its complete paper gate, authorization
and transitive input manifest. Each adapter loads its pinned sources and
receipts. Original candidates and phase-owned source files are unchanged.
All new native output files are created once and preserved. A later saving
must use a new candidate directory.

This revision corrects candidate08’s canonical variant import binding. The
failed candidate08 attempt and its successful process cleanup are preserved;
that attempt emitted no circuit and ran no native or official proof. The
paper arithmetic and protected phase blocks are unchanged. Product-forward
peak accounting is45 data owners (including word16) plus3 carry scratch.

AR005 changes the physical v3 owner during product inversion. The isolated lifecycle10
passes its mutable root list to that adapter, retains every old carry and table debt,
and uses the returned owner for seed cleanup and final input restoration.
