# Candidate06: complete Q48 native implementation plan

Copyright2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

The parent accepted the complete paper gate before any native source was written:
PAPER_GATE_RECEIPT_018_VARIANT.json, SHA256
99ef9a891d4e99b262b1a452ea48b18c536e91e7017f018b77bc37f1793ccffd.
The complete thirteen-component ledger and nineteen ownership cuts are frozen in
research/joint_loader/Q48_COMPLETE_PAPER_GATE.json, SHA256
912da9164095aa996317909903d50162a76eded7ff9a90cbb9299c85c013de2c.

Expected complete resources: Q48,1591 expected Toffolis,4T,34 generic rotations,
exact mathematical margin124372027 units2^-64, charge238.04838838550535,
predicted cost87842.32264250425. This is an expectation, not a measured cost.
Both coefficient preparation peaks and the compact endpoint peak are48.
The nonproduct lifecycle322.5 exceeds the old221.24 subtotal allowance; this
new completeQ48 budget is the accepted basis, not a claim to meet that old
unchanged-Q52 subtotal. All phase-debt obligations from the frozen gate apply.

## Isolated source boundaries

variant.py pins all inherited dependencies, installs the proven triangular
initializer/root-tail/angle/route changes from previous candidates, then installs
only the new divider cleanup and compact phase functions. generate.py owns the
complete Q48 builder and original input layout, and captures actual cumulative
resource/ownership cuts. lifecycle06.py owns changed scheduling and disposable
product carries. tables06.py replays actual61/80E certificates. decoder06.py
restores five values but applies only the remaining direct a6 correction.
phase06.py retains every generic angle while replacing the final constant
controlled phase by CZ. divider_cleanup06.py accounts for every feed carry.
All candidates01..05 remain unchanged on disk.

## Required evidence

No independent heavy/native jobs. The parent must run run_batch.py --full-proof
inside the shared512MiB native guard after SOURCE_READY and INPUTS are frozen.
The builder must enforce48 qubits and exact expected resources1591/4/34.
Fresh positive/negative integer50 checker tests, independent native simulator
checks, and the all-input/all-HMR text proof must all pass. The proof uses the
unchanged independent candidate04 oracle, all3133452 inputs, physical22-bit
input restoration, zero scratch, zero reset states, every measurement phase,
and exact equality with the independently scanned50-bit mathematical model.
No relaxed checks, sampled substitute, or modified tolerance is permitted.

Only after native PASS may the original verifier run its full domain/64shots
at saltsdefault,1,2,3. Original documented batch1792 and two workers use the
separate official-only640MiB envelope. All four must PASS before qualification.
No competition submission is authorized. Stop by2026-11-12 02:30UTC/07:30PKT.
