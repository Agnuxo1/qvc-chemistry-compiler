# Candidate07 table adapter

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

Authorized by PAPER_GATE_RECEIPT_022_VARIANT.json. Reuse candidate06 TableDebts, TableDebt, cleanup, model functions and affine-frame implementation as identical objects. Keep the complete first61 loader, replace the second80 certificate by the frozen delayed second79 certificate, and assert65 actual second-loader HMR debts. All caller ownership and decoder semantics are unchanged. Run only the bounded128-row AST-bound component owner/phase audit here; the parent owns fresh full native proofs and original four-salt verification.
