# Complete Q48 ring26 and79E loader paper gate

Copyright2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0. Credits: Opus and Astra.

This is a complete paper gate before native construction. Expected Q48,1584Toffolis,4T,33rotations; rotation charge230.84805946161188; total1815.848059461612E and cost87160.70685415737. Both coefficient preparations and the endpoint peak at48.

| Component | Expected Toffolis |
|---|---:|
| normalization | 97.5 |
| consuming_root | 198 |
| divider_disposable_feed | 587.5 |
| paired_product_disposable_owned_carries | 240.5 |
| coefficient_rows_two_forward_one_inverse | 123 |
| seed | 17.5 |
| coefficient_R_frames | 4 |
| H3_H4_preparation_and_restoration | 7 |
| root_value_decoder | 21 |
| first_loader | 61 |
| framed_second_loader | 79 |
| shared_table_cleanup | 9 |
| ring26_full_control_zero_global_endpoint | 139 |

The exact all-input phase screen has0 failures on3,133,452 inputs, minimum margin124370688 units2^-64, worst error/tolerance0.973575996935943. Full-domain independent phase50 digest: 8bd482a8957cd387a2b212afdaca656947b7f89c983d67ff4eea4e14c3b0a26a.

## Complete ownership and phase obligations

- First loader fixed26 plus work22 peaks48 and returns42; all original first-loader measurement phases remain recorded.
- Second R frame precedes load; fixed27 plus work21 peaks48, including4 existing raw inputs and17 newly zero owners; loader returns43.
- Second raw0/1/2/4 are consumed, their mixed phases belong solely to TableDebts; only the actual later a6 HMR outcome receives decoder directZ.
- Selected second loader has65 measurement phase functions, one more than candidate06; native code must derive rather than copy its HMR count.
- Existing universal128-row9E table phase cleanup pays the combined first/second loader and table-output phases; no full reverse loader is hidden.
- Paired product240.5E includes8 conditional owned-carry regenerations4E; divider587.5E includes13 conditional feed regenerations6.5E.
- Seed17.5E and all6 seed carry phases, both coefficient snapshots, H3/H4 preparation/restoration,21E root decoder and Rframes4E remain complete.
- New ring26 endpoint owns43 data+one+p+c+threshold+feature=48. It restores43 owners and repays/frees all15 local HMR functions.
- Ring26 route uses61 swaps each direction, all included; no old27 omitted-pair credit is carried over.
- Only33 generic sites emit rotations; global_one is exactly zero. Fixed4T and one directCliffordZ_POW are retained.
- New ring26 mathematical oracle must independently form all34 site predicates and match the exact accepted full-domain phase50 digest.
- Retain pinned checker semantics, all positive/negative exact50 tests, full3,133,452inputs/allHMR proof, restored originalx, zero scratch/resets, original verifier and default/1/2/3 salts.

## Budget interpretation

The old221.24 standalone allowance atQ52 was not crossed. The explicitly repriced wholeQ48 design has321.5E nonproduct lifecycle plus240.5E product =562E complete lifecycle. Its remaining fixed cost is1494.348059461612E. The whole score clears89987 by2826.29314584263 and does not reach82740. This is a modeled score pending new native and original four-salt proof.

The complete gate JSON pins every inherited and new evidence dependency. Preserve candidates01–06. No submissions.
