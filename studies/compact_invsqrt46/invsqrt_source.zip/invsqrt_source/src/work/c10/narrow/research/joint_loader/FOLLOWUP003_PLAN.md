# Follow-up003: split continuation and two fresh framed seeds

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits Opus and Astra.

This is source preparation for one parent-queued batch; no independent heavy
or native execution is authorized. Preserve all follow-up002 sources and
certificates. The fixed coefficient model and both output/phase interfaces
remain unchanged.

## Fixed ledger and finite variation

| Job | Fixed other owners | Mutable work cap | Q | Starting state |
|---|---:|---:|---:|---|
| First raw loader, resume seed8 prefix |26|22|48|Exact partial47E/11outputs from follow-up002.|
| Framed second loader, seed0 |27|22|49|Fresh11-AND bank plus four existing input work owners.|
| Framed second loader, seed8 |27|22|49|Same geometry with a different finite product-factor/output-basis search.|

The resume uses the existing `--resume` interface. It restores the exact work
truths, gate list, accumulated47E, peak22, and eleven loaded output parities.
It does not restart or charge the initial bank twice. The old partial is a
pinned read-only input; the continuation writes a new filename. Four further
independent outputs and the final one-AND A12 identity remain. With the
already exact Q48 second80, the earlier candidate03 comparison required a
complete first cost at most59; a partial result gets no such credit. Parent
candidate05/carry updates will determine any current complete gate.

The two framed second jobs vary the RNG controlling product-factor candidates,
output parity choices, and invertible retained-coordinate frames. Seed9
previously completed74E. Seeds0/8 are finite heuristic alternatives, not an
optimality proof. Each needs fewer than73E to improve the frozen second loader
at unchangedQ49. This is a better immediate gate than another Q48 second
search while the matching first loader is incomplete.

All jobs retain the actual physical-owner rules: R,a5,a6 are fixed in the
framed second chart; a0,a1,a2,a4 can become work only through injective
Clifford/HMR charts. Every discarded function creates an explicit TableDebt
in original raw-row order. The existing21-E root decoder restores values
without a duplicated direct phase correction for those early retired inputs;
the existing9-E shared cleanup repays the pure-table signs. No frame,
reconstruction, helper, or phase debt is free by assumption.

## Execution bounds and evidence

Three jobs run sequentially,20soft seconds each. Each worker has128MiB AS and
a32-second internal hard alarm. The parent wrapper retains the inherited
hard cap at at most512MiB, limits total wall time to90seconds, and further
limits each child timeout to the remaining batch budget. There is no compiler,
native builder, simulator, or verifier invocation. Compilation is excluded;
the already pinned own factor binary must exist.

Every complete witness is independently replayed from its initial physical
chart across all128 rows, including all invertible frames, every AND,
peak ownership, restored output meaning, and each HMR generator's phase
repayment. A result without a completed successful replay is not a survivor.
Partial and timeout evidence is saved atomically and does not close the
architecture. All files used by the batch are SHA-256 and byte-count checked
before any worker starts.

Parent command:

```
/usr/bin/python3.13 -u /workspace/scratch/40c9505bd2bc/narrow/research/joint_loader/run_loader_followup003.py
```

Source preparation only. Native changes require a new complete gate and
parent authorization; official qualification still requires all four salts.
