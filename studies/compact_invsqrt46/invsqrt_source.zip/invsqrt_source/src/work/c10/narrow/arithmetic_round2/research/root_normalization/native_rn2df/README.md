# Isolated normalization94.75 native component

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

Parent acceptance is the pinned NORMALIZATION9475_PAPER_ACCEPTED receipt.
The direct API is normalization9475.forward(builder,x22,flags4) and
normalization9475.inverse(builder,x22,flags4). No inherited module or file is
patched. Production uses the inverse's default omission flag (False).

Expected forward51.5, inverse43.25, full94.75; actual native localQ must be46.
The complete circuit remainsQ48. The endpoint, angles, model, two loaders and
shared table cleanup are unchanged. The simple95.0 paper fallback is preserved.

The proof parses the actual emitted native text, checks all22 leading support
classes (a strict superset of every original input), every active HMR outcome
including both conditional helper outcomes and the expanded forward parity,
every reset, original input/flag owners, and exact native expected resources.
It deliberately omits one helper phase to require rejection. Four native
simulator seeds independently check input/phase/scratch restoration.

Run only under the new arithmetic_round2 strict guard. Component proof is
separate from a composed fusion proof and the four original official salts.
