# Complete RN2-D plus RN2-F normalization94.75 paper composition

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

The separate RN2-D forward and RN2-F inverse have passed their full original
domain pure Boolean proofs. This composition selects exactly those immutable
functions: forward51.5E and inverse43.25E, totaling94.75. The simpler95.0
composition remains frozen as a proved fallback and is not changed.

The inverse's two selected original measurement outcomes mB,m3 are explicitly
branched into four equally weighted assignments. Every other original or new
active measurement outcome remains symbolic. The new composition checker must
also expand the forward cubic outcome parity into its four independent original
symbols. It must not treat that parity as an independent fresh random bit or
lose correlations with earlier corrections.

The forward peak is22 input+4 flags+20 prefixes=46. The inverse preparation
peak is22 input+4 flags+4 helpers=30; its final conditional phase uses28 owners
after metadata helpers are freed. Boundary26, exact owner order, original
input map and zero scratch/flags stay unchanged. GlobalQ48 still binds the
protected loaders and endpoint. No T, rotation, approximation or other block
changes are included.

Against candidate09, normalization96.5→94.75 saves1.75E: the complete modeled
ledger is1566.75 Toffolis,4T,33 rotations,Q48, rotation charge230.84805946161188,
expected cost86332.70685415737. Any further product/root changes require their
own complete composed gate. This is not a native or official measurement.

The full paper proof covers3,133,452 original inputs in every selected branch,
all active HMR symbols, a deliberately omitted helper correction, and exact
forward/inverse maps. Guard30seconds, hard512MiB, unchanged shared lock. Only a
positive parent-reviewed complete receipt can authorize isolated native work.
