# Arithmetic round 2: consuming root and normalization

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

## Scope and status

Authorized work window: 2026-11-12 03:30–10:00 UTC. This branch owns only
normalization/restoration, the consuming-root lifecycle, and compatible
arithmetic owner reductions. All previous files remain immutable. Native
construction requires a complete positive delta gate and parent review.
No heavy job may start before the new round's guards are ready and the parent
grants the shared execution slot. No submissions, uploads, or child agents.

Read first: `narrow/RESUME.md`, `FINAL_RESULTS.md`, `CLOSED_ROUTES_NARROW.md`,
the relevant base/checkpoint002 closures, the frozen pair-normalization source,
candidate03's root specialization, and the verified FA004-v6 report and
source-aware cleanup source. The old handoff's expired stop time is historical;
this new parent assignment supplies the current authorization.

The user-reported Mac/Rust default-batch four-salt result (maximum about
87,160.709) is external user-reported evidence only. Our comparison baseline
remains candidate07's pinned exact native expectation and completed local
four-salt receipts.

## Fixed complete ledger before experiments

| Part | Expected Toffolis | Peak/interface |
|---|---:|---|
| Pair normalization and restoration | 97.5 = 53 forward + 44.5 inverse | Local peak46; n22+flags4 at body boundary |
| Consuming root and inverse | 198 = 99+99 | Local peak41 includingflags4; root12+signedresidual10+flags4 |
| Every other candidate07 arithmetic component | 1,288.5 | Frozen; global peak48 |
| Total | 1,584 | Q48 |
| T gates | 4, charge1 | Frozen |
| Generic rotations | 33, charge230.84805946161188 | Frozen endpoint and phase model |
| Complete expectation | 1,815.848059461612 equivalents/shot | Cost87,160.70685415737 |

A proved exact saving of delta E in this branch changes the complete expected
cost by exactly48*delta if every interface, phase function and global peak is
preserved. The82,740 stretch requires at least92.098059461612 E combined savings
from all arithmetic branches. This branch alone would need root+normalization
at or below203.401940538388 E to supply that entire saving; no such claim is made.

Both coefficient preparation peaks and the endpoint already bind at48. Reducing
this branch's local peak alone does not lower global Q. No owner or classical
phase debt may silently survive our boundary and consume an unpriced wire in
the frozen downstream lifecycle. Endpoint, rotations, shared table/endpoint
phase cleanup, and coefficient loaders are outside this branch. Internal root
and normalization measurement corrections remain explicit local obligations.

## Initial source findings

1. Pair normalization is already the new direct pair map, not FA004's122E
   semilog/packed interface. Forward is18 prefix ANDs +34 controlled swaps +1
   helper; inverse contains the34-swap inverse plus thermometer/phase work.
   A different forward or inverse must preserve n=x*4^k and the four existing
   binary exponent flags exactly.
2. Root198 already includes the known-zero tail-pair saving8E. Repeating that
   specialization is not new work. The remaining root cost is mostly growing
   adders; every carry and sign consumed into the next root digit matters.
3. FA004's transferable idea is to derive a missing/cleanup value from the
   actual live source coordinates at the exact restoration cut, then repay
   local helper phases before those controls change. Its fixed Blo/R decoder
   and numerical table do not apply to our root/norm interface.

## Ordered paper studies

### RN1: inverse-normalization source-aware phase cleanup

Audit the10 thermometer erasures after routing. Price whether products or
affine relations already present in the restored input and neighboring
thermometer controls replace the9 conditionalCCZ terms, including every
preparation and erasure. Initial possible saving bound is only4.5E unless
thermometer preparation or routing also changes. Count classical guard
expectations exactly. A helper that costs more than the removed conditional
work is rejected; no source relation may assume unavailable original input.

### RN2: pair-normalization route using zero support

Inspect the17-swap-per-lane prefix route and its input promises. Look for
actual zero/affine controlled-delta identities or a separately constructed
zero-supported route with fewer swaps. Audit forward and inverse separately;
an information-count argument earns no gate saving. Record every swap owner
and control at the binding cut. If identical routing is mandatory for the
selected family, close only that family.

### RN3: consuming-root source-aware carry/terminal arithmetic

Decompose each j=1..12 step and final residual conversion. Derive the exact
valid intermediate code from normalized input prefixes, including tail-zero
promises. Examine leading-bit carry formulas and low three-bit wrappers for
affine/quadratic output relations; any shortcut must preserve all root and
residual bits and prove each HMR phase. Price complete forward+inverse, not
just one direction. Root-internal transformed coordinates must be undone
before returning root12/residual10 to the frozen coefficient producer.

### RN4: combined normalization/root boundary

Only after the local studies, consider eliminating normalization intermediates
using the consuming-root input schedule while preserving the existing root
and exponent outputs. A new streamed input permutation or partial conversion
must provide explicit reversible owner movement, full restoration and no
new held register through the frozen body. This is a new chart, not a free
transfer of the old Stage94 normalization or an old narrow Stage97 route.

## Evidence and gates

Before each experiment, save its concrete ledger, affected source pins and
declared care domain in this directory. Lightweight source reading and exact
small Boolean algebra are allowed; any full-domain or native execution uses
the new guard and parent's serial slot. A surviving candidate needs:

- exact original-domain map and every local HMR coefficient;
- current physical-owner updates, zero scratch and unchanged spectators;
- complete local expected Toffoli/T/rotation counts and allocation peak;
- complete unchanged-body cost after the delta, with no accuracy change;
- independent parent review before native construction.

Scoped failed families and useful exact identities are preserved separately.
Continue to the next structured study after a closure; no universal lower
bound is inferred from a finite decoder or route search.
