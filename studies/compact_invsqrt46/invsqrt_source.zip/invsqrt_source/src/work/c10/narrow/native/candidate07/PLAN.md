# Candidate07: complete Q48 ring26 and79E-loader native plan

Copyright2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0.
Credits: Opus and Astra.

The complete paper gate was accepted before creating this candidate's source.
Root authorization is PAPER_GATE_RECEIPT_022_VARIANT.json, SHA-256
f8cfe4331b37a5184a4aab17ee85b4ac892c08c2cfb863fc4b1c1b3c9978262e.
Complete gate is research/combined_q48_ring26/COMPLETE_GATE.json, SHA-256
49ce6e7007b19abcd533b82a9f291b617cbc1c864a3d66287c0e63a87ebb82c4.

## Complete expected ledger

Q48;1584Toffolis,4T,33generic rotations. Rotation charge230.84805946161188,
1815.848059461612equivalents/shot and87160.70685415737predicted cost.
Both coefficient preparations and the phase endpoint peak48. Original
mathematical tolerance is unchanged. The full official input-domain phase
screen has0failures and minimum margin124370688units2^-64. This number
and the cost are mathematical/native expectations until fresh native proof
and original four-salt qualification complete.

The selected first loader is the frozen61E Q48 witness. The delayed-input
second79E witness has65HMR functions, consumes original address slots0/1/2/4,
and returns the exact same43-owner chart as candidate06. Existing universal
9E table phase repayment handles all signs. The later direct a6 measurement
is separately paid by the existing21E root-value decoder.

Candidate06's lifecycle, decoder, and divider arithmetic are reused as frozen
functions with their original module identities. Their563E historical component
contract describes the original61/80pair; the new selected lifecycle is562E.
The complete emitted-circuit expectation must be exactly1584/4/33, independent
of historical contract labels.

The new26-bit endpoint uses61CSWAPs each direction,1known-one owner and both
p/c controls. It costs139Toffolis/4T/33R, peaks43+1+2+1+1=48, and repays all15
local HMR functions before returning43owners. There is no old27 route omission
or old complemented-j0 shortcut. Global-one angle is exactly0 and is omitted.

## Proof and guard obligations

The phase oracle is new and explicitly bound to candidate07. Its complete
phase50 stream must equal independently scanned digest
8bd482a8957cd387a2b212afdaca656947b7f89c983d67ff4eea4e14c3b0a26a.
The inherited bit/phase checker stays pinned. Retain5positive/9negative exact50
unit tests,4seed native samples, diagnostic text proof, and exhaustive proof
for all3,133,452official inputs and every emitted HMR variable/transcript.
All original input owners must be restored, all scratch and resets zero, and
phase equal exactly on the2^-50 grid. Derive actual HMR count from emitted text.

The parent alone runs run_batch.py --full-proof under the existing512MiB
strict shared guard. Original official verification follows under the640MiB
shared guard, exactly2workers and documented batch1792. Every original input
and64shots/input must pass on default,1,2,3. No partial, failed or changed-circuit
records may qualify. Resource limits cause splitting, never unchanged retries.
All prior candidates01–06 and the original verifier remain byte-for-byte frozen.
No submissions. Launch cutoff02:20UTC; worker hardstop02:25; user stop02:30UTC.
