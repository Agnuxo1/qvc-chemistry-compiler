# Candidate06 source-stage restart

Copyright2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This file is part of the frozen source bundle and must not be edited after
SOURCE_READY.json is created. Current outcomes belong in ../../RESUME.md and
result files. A complete positive Q48 paper gate authorized this isolated build.
See PLAN.md and the pinned parent receipt for the exact scope and budget.

Reproduce under the parent shared native resource guard:
/usr/bin/python3.13 narrow/native/candidate06/run_batch.py --full-proof

Expected1591Toff,4T,34R,Q48, predicted87842.32264250425. At source preparation
there is no emitted native circuit and no official qualification. The retained
independent oracle has exact minimum margin124372027 units2^-64. All generic
angles are unchanged from candidate04; all prior candidates stay immutable.

After all native checks pass, run the original four-salt suite with this KMB
and whole_native_text_all.json, under the reviewed official-only guard. Use
fresh evidence and guard filenames. No submission. Hard stop02:30UTC.
