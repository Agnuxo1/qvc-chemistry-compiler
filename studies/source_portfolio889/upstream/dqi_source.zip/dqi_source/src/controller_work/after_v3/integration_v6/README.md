# Fixed third-chart integration: internal v6, planned public v5

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This is a separate source composition of the frozen v5b arithmetic and the repaired third public chart. The planned public release name is **v5**; its internal implementation and evidence paths remain **integration_v6**. The frozen v4, initial-v5 and v5b sources are unchanged. No build, native test, classifier, sampler or official job is launched by preparing this directory.

The selected arithmetic is the six matched191/195 special inverse calls, the real zero-residue correction at the third pivot, public transpose window14, cubic20/paired62, and every selected v4 component. No adaptive mask gauge, alternate field tensor or width change is selected. The public generator still accepts no input profile, terminal, gap set, salt or contact information. It fixes cutoff15 and all4095 physical scan positions.

## Exact source model

| Stage | Static T |
|---|---:|
| Extractor, rolling flags, gauge and padded seed |151852|
| Synthesis |65076|
| Full degree35 preimage |115025|
| Projective finish |7856|
| Retained-inverse finish/preimage seam |−92|
| Full scan |44275|
| **Total** |**383992**|

The helper ownership model remains **Q889**. The exact full fresh-mask expectation is

`13165890612252429/34359738368 = 383177.84819089656`.

Relative to the frozen v5b source model, this is55 static T and `277582827/4194304 = 66.18090319633484` expected T saved. Relative to the frozen v4 source model, it is357 static T and `3090097999/8388608 = 368.36838710308075` expected T saved. These expectations are source models, not official sample means or costs. The complete new tape, exact native event ledger, joined tests and four fresh original verifier returns remain required for a released gain.

The key alone is216928 static T with a101087T prefix and expectation `28402108715/131072`. The preimage remains the v5b115025T pair/57034T prefix with expectation `3932776829832973/34359738368`. `SOURCE_MODEL_LEDGER.json` keeps all deltas and their scope explicit.

## Source ownership

`v6_pipeline.configure()` loads the immutable accepted runtime first. It binds `last_return_retained_norm` on the unchanged generic arithmetic before importing `first3_retained_norm_adapter`. The new adapter captures that same arithmetic and uses `inverse_retained_norm_deferred` for its six special inverse pairs. The global closed-inverse binding remains `quotient_phase84_mask_guard`; the new special provider is not installed as an arbitrary-source replacement.

The prefix borrows the otherwise unused constant-one24-bit carry bank and the tail controller's initial zero predicate. It restores carry1 before generic extraction starts at index3, and HMR-resets the borrowed tail predicate without freeing its physical allocation. The six six-bit norm masks and one zero-predicate mask remain as37 classical bits. The matching return closes every actual debt, releases its separately allocated return predicate after the ordinary tail has closed, and restores carry1 before the original owner frees it.

The preimage keeps `transpose14_core` and `transpose14_window`, binds the existing handoff outer to that core, and uses `paired_phase62` on both paired quotient sites. The source, local-mask, gauge and handoff lifetimes are inherited from the qualified v5b components. The scan, finish, public geometry and original syndrome-mask gauge remain unchanged.

## Eleven mandatory component gates

`COMPONENT_GATE_PLAN.json` pins the unchanged nine v5b component gates plus the third-chart local and physical gates. The first nine validator bodies are unchanged from the frozen v5b producer. The new local gate requires20480 fixtures, explicit raw zeros and zero cross coefficients, two builds, three HMR seeds, exact observed-mask counts and phase/restoration. The new physical gate requires all783 cases, the old76 exclusions, both actual gauge branches, the deterministic raw-zero input and both public-carry boundaries.

The actual third-chart reports are already available and hash-bound by the plan. That does not substitute for the remaining dependency checks or a new full decoder. A source plan, smoke report or successful source review cannot enable emission. `NATIVE_COMPONENT_GATES.json` is written only by the separate receipt producer after every full gate passes.

Root-only receipt-production commands, invoked under the shared guard:

```sh
/usr/bin/python3.13 -B controller_work/after_v3/integration_v5b/prepare_component_gates.py
/usr/bin/python3.13 -B controller_work/after_v3/integration_v6/prepare_component_gates.py
```

Each refuses to overwrite an existing manifest. The v5b producer preserves the fallback; the v6 producer independently revalidates the nine inherited gates plus the two new ones. Neither launches a native job or reads an old compiled tape.

## Eight joined test roles

The old rare physical input remains a regression input even though its gauge label is different under the new chart. The actual new gauge-one case is an original weight18 corpus member, case ID `54d38bf59904d025bfe626a0db3007111eb8d6c3e975bf0dda3a99d8a4cba57a`. The new raw-zero case is the admitted weight16 deterministic construction, ID `6663887a36baed1286a39bd8933a2c4d45a0660ef96a6a2b03ea0460588e00b0`.

| Joined role | Required inputs and scope |
|---|---|
| `key-full` |All781 original key-admitted cases and all76 explicit original key exclusions; new third-chart boundary oracle|
| `fixed-native` |All10073 original cases,6140 admitted/3933 excluded, original masks and all three seeds; no omitted exclusions|
| `physical42` |All42 original full-scan physical fixtures, covering every weight15 through35|
| `legacy-rare-key` |The exact old first-two rare physical input, retained as a key regression input|
| `legacy-rare-native` |The same old input through the complete4095-position decoder|
| `gauge1-key` |The actual v6 gauge-one input with the independent changed-carry boundary oracle|
| `gauge1-native` |The actual v6 gauge-one input through the complete decoder|
| `raw-zero-native` |The constructed third-raw-residue-zero input through the complete decoder and original physical phase oracle|

The special panel preparer writes two fresh standard one-case packages without drawing inputs or masks:

```sh
/usr/bin/python3.13 -B controller_work/after_v3/blocks/v6/prepare_integration_special_panels_v2.py --output controller_work/after_v3/blocks/v6/runs/integration-special-panels-v2
```

It pins the actual783-case evidence, rechecks unchanged full admission and both scalar boundaries, and preserves exact positions, magnitudes, canonical IDs and mask modes. Its preparation manifests are not native PASS receipts. The standard native checkers still own their original mask seeds and all value/phase/restoration checks.

## Fresh full build and release workflow

After the selected component manifest exists, root may invoke the public generator in a fresh output directory:

```sh
/usr/bin/python3.13 -B controller_work/after_v3/integration_v6/gen_dqi.py --output controller_work/after_v3/integration_v6/runs/a/dqi.kmb --log-directory controller_work/after_v3/integration_v6/runs/a/build
```

Build B must use the unchanged generator from a fresh staged source closure, with absolute output/log paths if they remain under the main run directory. The equality checker requires complete byte equality, source inventories, environment, runtime bindings, event ledger and stage sequence. A later actual-runtime source census uses the unchanged original tool and the actual copied Python-file count; no source audit exception is created here.

Root schedules the eight joined roles and four full original verifier salts. Every positive official error must be attributed with the unchanged sampler and exact original batch seeds; no new draws or favorable salt/hash selection are allowed. T gain banking and the351e9 price goal are separate conclusions. An improved mean T does not imply that every observed salt price improves when the actual integer failure count changes.

The source packet does not itself declare portable, native, official, population or target-price success. Frozen population evidence transfers only after the unchanged-admission argument and actual selected-source/receipt chain are qualified. The two historical source-document exceptions remain documented in the existing optimized-binding addendum; this packet does not rewrite them.
