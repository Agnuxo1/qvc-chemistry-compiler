# Matched first-two norm debts: additional3T source candidate

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

**Separate prepared variant; no native job has been run.** The frozen195T closed-inverse provider and its queued checks are unchanged. This candidate replaces both sides of the three special first-two inverse pairs, so it is an alternative provider bundle with3 additional fixed/mean T saved. It must not be combined by double-replacing the same calls or credited before its own emitted gates pass.

## Exact new debt

The retained-stack inverse computes the original K24 norm N, its child norm h in GF64, and gamma=inv0(h). The prefix follows the195T arithmetic map and all its exact HMR repayments except the four-T scalar repayment of the six-bit child mask. It HMRs h in the existing quadratic6 tower chart, retains that actual mask m, and returns the bank to zero through the same gamma/inverse-norm erasures. Its sole open phase is therefore m dot tower6(h(entry S)). The map costs191 fixed T and returns inv0(S).

At the matching return, the source has been restored to inv0(the exact prefix entry). Relative norms commute with inversion, including the zero-extended branch. Its newly computed child reciprocal is

`gamma_return = inv0(Norm12(Norm24(inv0(S)))) = Norm12(Norm24(S)) = h_prefix`.

Immediately after the existing source-preserving cubic child inverse, the return converts this owned gamma word to the quadratic6 tower chart, applies CZ with the exact stored prefix mask, undoes the chart and frees the mask. This costs zero T and no additional quantum wire. The source-preserving reciprocal is back in polynomial form before reassembly reads it. The remaining return is exactly the195T locally closed stack map; its own child HMR mask still gets its ordinary four-T scalar phase. The zero source obeys every identity and creates no new exclusion.

PrefixRecord binds the actual builder, physical source, extension and live six-bit HMR mask. The return rejects a closed or mismatched record before emission and marks it closed only after all local storage is returned. These checks do not purport to inspect the quantum value: the matching compute/uncompute caller supplies the inverse of the prefix entry, just as in the existing deferred inverse contract.

## Both carry lifetimes are public

Before the first two pivots, the original production carry is the public constant1 and none of the three special inversions or intervening public coordinate transforms reads it. The adapter creates the existing tail controller first; its initial zero flag remains owned. It X-resets carry bit0, uses the full zero24-bit bank in each of the three191T inverses, restores X, then starts the unchanged generic loop at public index2. Thus the prefix peak is840 query bits+24 carry bits+1 initial tail flag+24 fresh helpers=889.

On return, the unchanged generic reverse loop restores the same carry1 at index2. The tail closes before the matching special inversions. The adapter uses the same public X reset, the three195T matched returns, and X restoration before the original owner frees the carry. This is864 retained+24 fresh locally; earlier spans still set global Q889. No tail flag or arbitrary dirty value is borrowed as clean.

The three saved classical masks remain live through the intervening reversible computation and diagonal oracle. Each is paid against its own exact original-source child norm before the corresponding return chart changes. There is no added arithmetic function, mode flag, physical-input filter or population event. The old arbitrary-initial-carry component ABI remains untouched and is not claimed by this production-only adapter.

## Counts and events

| Per matched inverse pair | Frozen v4 | This candidate |
|---|---:|---:|
| Prefix static T |192 |191 |
| Return static T |276 |195 |
| Pair static T |468 |386 |
| Pair fresh-HMR expectation |468-84/2^24 |386-4/64 |
| Fresh helper maximum |24 |24 |
| Supplied known-zero storage at special seam |none used |24 already-owned carry bits |

Across three pairs the saving is246 static and 1032585153/4194304 mean T (246.18748497962952). The195T return-only candidate already saves243 static and243.18748497962952 mean; this matched variant adds exactly3 in both measures. The new key prefix is101055, pair216983, exact mean909145061707/4194304 (216757.0738093853). These are source counts until the native gates pass.

The scalar_inverse_six event still occurs exactly four times in the full key: one unchanged final generic return and three new special returns. The deferred prefix mask repayment is a zero-T CZ, so it creates no extra event or probability discount. The entire expected event multiset is unchanged from the195T source note, and the checker requires exact equality. No old retained-child30/outer54 event survives.

By the fixed public source loops, three additional old66T nested inverse stages are replaced on the prefix. Relative to the historical72 key/122 whole nested-stage reference, the matched variant has66 key/116 whole such stages. These are source-derived stage counts, not a new native instrumented measurement; the old reference discount must not be recomputed and added again, since the explicit246T delta already contains the replacements.

## Native qualification prepared for root

The isolated checker builds a value-only191T prefix with its declared open phase, then a fully phase-checked386T matched pair. Each has two identical builds, three HMR seeds and20480 full fixtures: three complete4096-element source lines,4096 arbitrary K24 values and4096 repeated zeros. It preserves arbitrary dirty bystanders, probes, all24 owned storage bits and unowned scratch. The paired nonlinear oracle is independent physical polynomial inversion. The fixture copies both actual child HMR masks classically; only the return mask affects executed T, so the exact aggregate count is386 per shot minus4 for each observed zero return mask, plus the three explicit probe T.

The physical-key checker retains the old source-preservation gate, independent physical oracle,781 original admitted inputs, rare gauge-one input and76 explicit exclusions. It builds four tapes twice: full key prefix, full paired key, the special-prefix carry boundary before generic index2, and the reverse carry boundary after generic index2/tail closure. Both carry tapes require all24 bits to equal1. The prefix boundary also checks the still-owned initial tail flag is zero. Their phase debts remain open and are not described as closed phase tests. The full paired key checks every restoration and arbitrary diagonal/cubic probe, all three records retired, both actual ownership lifetimes, exact event multiset and current replacement source identities.

Root-only isolated smoke command:

```sh
/usr/bin/python3.13 -B controller_work/after_c5/root/guard_wait.py \
  --log controller_work/after_v3/blocks/v5/runs/norm-deferred-smoke.guard.json \
  --stdout controller_work/after_v3/blocks/v5/runs/norm-deferred-smoke.stdout \
  --rss-soft 3000000000 --reserve 4000000000 -- \
  /usr/bin/python3.13 -B controller_work/after_v3/blocks/v5/check_inverse_retained_norm_deferred.py \
  --per-mode 32 --output controller_work/after_v3/blocks/v5/runs/norm-deferred-smoke
```

The full isolated command uses4096 per mode and fresh norm-deferred-full paths. Then root may run the production smoke:

```sh
/usr/bin/python3.13 -B controller_work/after_c5/root/guard_wait.py \
  --log controller_work/after_v3/blocks/v5/runs/first2-deferred-smoke.guard.json \
  --stdout controller_work/after_v3/blocks/v5/runs/first2-deferred-smoke.stdout \
  --rss-soft 3000000000 --reserve 4000000000 -- \
  /usr/bin/python3.13 -B controller_work/after_v3/blocks/v5/check_first2_retained_norm_deferred_adapter.py \
  --smoke --output controller_work/after_v3/blocks/v5/runs/first2-deferred-smoke
```

The full physical-key command omits smoke and uses fresh first2-deferred-full paths. No part of this preparation is an emitted whole-decoder result or a four-salt price claim. Selection into a new integration remains conditional on these gates and root approval of the actual receipts.
