# Independent source review of the v5b nine-gate packet

Copyright 2026 Syed Asad Ali. SPDX-License-Identifier: Apache-2.0.
Credits: Opus and Astra.

**No source-level blocker was found in the reviewed version.** This review
covers the pure binding/receipt producer, fixed plan, inherited and derived
validators, and the five build/panel wrappers. It does not execute a gate
producer, import an emitter, build or simulate a circuit, generate a physical
fixture, or make a statistical or official-price claim.

## Exact reviewed files

These paths are relative to `controller_work/after_v3/integration_v5b/`.

| File | SHA256 |
|---|---|
| `v5b_binding.py` | `e50cbe2372a99c5b954a4b94e9a213d773f9d939ab1fea0bd0b2613a83b72126` |
| `prepare_component_gates.py` | `064711f96902297c9c1cfcc579bb7afed73a27e10113e7bd9bc54d69bd425b6d` |
| `COMPONENT_GATE_PLAN.json` | `a456fd4a9cc229ecc5b2c36612e0777c890e49019db2a348d02e81d6ab44b617` |
| `COMPONENT_VALIDATOR_DERIVATION.json` | `f2fd0398b6daaea01d1171ffa7e5b6d275f59633bb09a2853b6db55aec77960f` |

The final bounded source check rehashed all78 plan entries, verified their
byte counts, and confirmed that all39 initial-v5 source-plan entries are
preserved exactly. In particular, the two original/rare key fixture files
and the three reused key checking helpers remain pre-pinned. There is no
regression to accepting merely self-reported hashes of a replacement corpus.
The v5b native manifest was absent at the time of this review.

## Preservation and false-completion checks

The reader preserves both the exact frozen v4 component/runtime chain and
the initial v5 source preparation. The latter is bound to source packet
`6c347cbd1bd5c836d9e56f272f20a44f805103db85b7e72b945e42825be7f9ba`
and the reviewed39-file plan
`0b4932be57dadb5ea3f70794d7635ed9b5db09a34f4ed4a05e5a3acf6d4b0518`.
It does not require an unbuilt initial-v5 tape or infer an initial-v5 official
result. All nine selected actual full gates remain mandatory.

The producer accepts only the planned checker paths, ordinary Python3.13
with `-B`, the recorded workspace, exact report output directories, and a
normal completed guard with integer exit0 and no stop. A smoke option is
not accepted. Optional fixture-size arguments are restricted to the full
required values. Positive batching options can change computational batch
sizes without changing the required contiguous case/seed coverage.

Parsed report bytes and every consumed source are recorded and rehashed
before publication. The producer refuses existing destination/temp files,
and a missing or invalid gate cannot produce a completed manifest. The
binding then requires the manifest's exact plan/producer digests, frozen
parents, nine names, source map, report paths, passed statuses, and normal
guards before native-dependent providers are enabled.

## Validator coverage

The original four validator functions are byte-identical to the reviewed
initial-v5 producer: `check_norm195`, `check_first_two`,
`check_transpose11`, and `check_preimage`. Their retained scopes are the
20480-source195 inverse, complete782-case original-plus-rare production key,
256-case isolated m11 handoff, and the266-case preimage caller.

The new matched-norm gate requires all20480 inputs in the same five modes,
three seeds, two identical builds, prefix191/pair386, Q889, and the actual
six-bit HMR masks. The prefix explicitly retains its six-bit phase debt;
only the pair checks a closed phase. Its exact T total discounts the one
return cleanup mask, never the deferred prefix mask. All nine malformed
record/source contracts must be rejected.

The matched production-key validator was independently reconstructed from
`check_first_two` using the eight recorded edits and function rename. It
keeps all782 cases,76 original exclusions, both gauge classes, and full
prefix/pair phase/restoration checks. It adds complete native observations
of both public-carry seams and the initially zero tail flag. It requires
three matched prefix masks retired at their exact returns. Its pair/prefix
counts are216983/101055, and the original event multiset is retained.

The cubic20 validator requires every64-by-64 denominator/numerator pair,
three seeds, phase and cancelling-pair panels, two builds, ten helpers,
20/40 T before the three probes, and full value/phase/scratch restoration.
The quotient62 validator retains all six tensor/reference/candidate
prefix/pair panels over20480 fixtures. It checks zero inputs, all denominator
values, all numerators at zero denominator, actual22-helper candidate width,
and exact62-T action counts. These isolated claims remain distinct from
the18-call preimage model.

The phase62-plus-transpose14 validator was independently reconstructed from
the reviewed `check_preimage` using its eight recorded edits and function
rename. It preserves all256 originals plus the ten fixed supplements. The
six cutoff-only excluded supplemental cases remain labeled as whole-decoder
exclusions; four supplemental cases are fully admitted. All are within the
preimage component domain, and no new physical inputs or population draws
are claimed.

The caller gate requires prefix57034/pair115025, Q889, all four handoffs at
sizes12/15, all32 local debts retired,14 gauge parks/unparks, two parked
payments, and the one existing top16 query. Its18 paired calls must each
declare two targets,89 static T, and22 owned helpers. The complete event
list may change only the paired63 names to paired62 and the RHS-zero cost
from36 to35. The exact caller difference from frozen v4 is
`-56 + 18/2^24`, with no extra local-debt discount or altered gap exclusion.

## Wrapper and schema checks

The build, production generator, equality checker, and candidate checker
are exact initial-v5 copies after the declared `v5`/`V5` name substitutions.
The key checker has only those substitutions and the explicit additional
`expected_prefix -= 3` with its explanatory comment. The old loader,
independent oracle, source-scale adapter, native checks, and probe handling
are retained.

The new validator field names and scopes were compared directly with the
held matched-inverse, matched-key, cubic20, quotient62, and combined caller
checker sources. The source checks consisted of AST parsing, literal
function reconstruction, exact hashes/sizes, and reading those report
writers. They invoked none of the validators, checkers, or producers.

The fixed public cutoff15,4095-position scan, and Q889 cap remain explicit.
The larger local phase helper count22 is recorded as a width-compatibility
obligation for any future merge with other width work; no such merge is
approved here. Full v5b emission, joined qualification, two identical full
builds, source-census/transfer checks, and four fresh original official runs
remain separate required gates. Neither old prices nor a source expectation
are presented as those new results.
