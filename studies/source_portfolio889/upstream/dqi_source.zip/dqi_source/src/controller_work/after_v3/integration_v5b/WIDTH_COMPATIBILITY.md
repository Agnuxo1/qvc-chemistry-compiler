# V5b helper compatibility boundary

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

The selected source model keeps the complete maximum at Q889. This statement
has a specific caller and does not authorize a future width merge.

The 62-T quotient phase retains two six-bit computed words for the K24
norm and relative numerator. The cubic20 trace helper requires ten further
bits, for **22 helpers** in the full quotient phase. The old 63-T provider
used 18 helpers. Source, target, reciprocal and gauge storage outside this
phase are still owned by the unchanged paired caller. The selected full
266-case caller gate must measure Q889 with the actual provider installed.

A different caller that has made four of those helper positions unavailable
cannot inherit the old 18-helper proof. It must provide an explicit lifetime
schedule and pass its own native phase, restoration and peak-width checks.
No whole-circuit width gain is claimed by this composition.

The matched first-two provider uses a different, publicly owned lifetime:
the 24-bit carry is exactly constant one before the first-two prefix and
after the generic return and tail close. A public low-bit toggle exposes
24 clean bits, and the provider resets all of them before the owner restores
one. This is verified at both production seams and is not a dirty-bank or
arbitrary-initial-carry promise. The three saved six-bit prefix masks are
classical storage, are matched to their exact records, and are freed only
after their Clifford repayments at the corresponding returns.

The added transpose14 uses the same caller's existing predicate handoff,
local-mask repayments and gauge lifetimes. All four handoffs, 32 local debts,
14 park/unpark cycles and two parked-scale payments remain counted. These
identities support the selected Q889 model; they do not remove any live
storage without a separately proved and tested schedule.
