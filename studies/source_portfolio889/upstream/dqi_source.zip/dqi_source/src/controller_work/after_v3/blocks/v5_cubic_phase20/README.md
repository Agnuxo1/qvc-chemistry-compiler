# GF64 cubic trace quotient20 and GF4096 joint phase62

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This is a new source-only candidate beyond frozen v4. It is not selected,
native-qualified or officially banked at preparation. Root runs every job
under the same shared guard. No width project, admitted-domain change or
population draw is involved.

The exact value polynomial of the existing cubic GF64 inverse is a sum of
nine products of an adjugate parity and a two-bit norm parity. Its shared
scaffold costs11 T and10 quantum helpers. For each output weight w, the
absolute trace pairing with the quantum numerator is the parity whose bit i
is Tr(w*(1<<i)) in the original GF64 polynomial basis0x43. Replace each value
product by one CCZ on the two scaffold parities and that numerator parity.
The source and all scaffold values remain unchanged. Reverse every temporary
parity transform, then apply the existing phase-exact0T scaffold erasure.
The result is20 T/10 helpers on every denominator and numerator, including
zero. The inverse output is never allocated or measured.

The selected v4 joint phase first computes a GF64 norm and relative-trace
numerator together with its42-T dual-number tensor. Using this20-T phase
in place of the21-T quadratic phase gives62 T, with12+10=22 helpers. All
existing final work-word HMR debts still use the unchanged bilinear and
linear witnesses before the denominator and numerator charts are restored.
The old63-T body used18 helpers; the old65-T implementation already used22.
Only an actual caller check may establish the complete preimage remainsQ889.

The two-target classical-mask adapter is otherwise an exact derived sibling
of paired_phase63. Its exclusive branches cost62 and27, so its static count
is89; with the original independent fresh masks its exact expectation is
62−35/2^24−27/2^36. Across18 selected calls the mean saving is
18*(1−2^-24)=150994935/8388608, approximately17.999998927116394 T.
This saving is additional to the transpose placement only if the combined
caller passes, and to first-two195/+3 only if the complete joined candidate
passes. SOURCE_LEDGER.json contains exact fractions. None is a measured
full-circuit mean at this source checkpoint.

DERIVATION.json records every change from the actual selected63-T files and
its unchanged checker. The separate small-field checker uses independent
polynomial arithmetic on all4096 denominator/numerator pairs, three actual
HMR seeds, phase and double-phase circuits, arbitrary dirty bystanders and
classical probes, complete scratch restoration, exact operation totals and
two identical builds. The larger gate retains all original six panels:
dirty-target dual42, reference63 and new62, each as a single and paired body,
20,480 fixtures per panel and three seeds. All4096 denominators are covered
per mode; all numerators at denominator0 are covered. This is not an
exhaustive2^24-input assertion for the two12-bit words.

The production preimage gate is prepared separately with the proposed
transpose14 placement: original256 fixtures plus10 explicit saved-profile
supplements, both gauge charts, exact18 paired calls, four owned third-flag
handoffs, and no changed HMR event law. Its numbers remain modeled until the
native receipt passes.

Root queue `root/native_queue_v5_02.json` runs smallsmoke→full and largesmoke→
full sequentially; each child has a2.5GB soft cap/4GB available reserve and
shared blocking lock. Source-only independent review is in
blocks/v5/CUBIC20_QUOTIENT62_SOURCE_REVIEW.md. No old provider is overwritten.
