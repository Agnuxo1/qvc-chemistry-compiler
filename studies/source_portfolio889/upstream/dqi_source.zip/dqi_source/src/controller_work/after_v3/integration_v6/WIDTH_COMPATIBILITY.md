# Current Q889 contract and future width merges

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This selection changes T arithmetic while retaining the current whole-decoder Q889 limit. It makes no independent width claim.

The repaired third prefix uses the840 physical syndrome/head bits, the existing24-bit carry bank and the existing initial tail predicate. Its inverse helpers peak at24 additional quantum bits. The tail predicate is HMR-reset without being freed, and carry1 is restored before generic extraction starts at index3. Its37 pending special masks are classical bits.

The special return begins after the ordinary tail has closed, leaving864 retained quantum bits. The return predicate and24 inverse helpers then reach889. The carry bank is clean at each matched inverse boundary and returns to public1 before its original owner frees it. The boundary checks must be retained when composing another optimization.

The inherited cubic62 quotient phase uses22 local helpers, compared with18 for its prior63T provider. That difference is safe in the selected existing caller and is explicitly pinned in the runtime ledger. It could affect another engineer's future width merge. A lower-Q claim requires a new complete lifetime and native caller gate; it cannot be inferred from this T-only packet.

No alternative width provider, dirty-bank extension, arbitrary-initial-carry promise or adaptive compiler branch is selected. The exact source model and observed component peak must still be confirmed on the new full tape.
