# Public v6 candidate: internal integration_v7 adaptive64 gauge

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This directory reuses the preserved unfinished adaptive64 scaffold discovered
in the historical workspace. Its original twelve files are snapshotted under
`post_v5/integration_preparation/original_draft`. Accepted public v5 remains
`integration_v6` and is unchanged. New source, component, emission, joined-panel,
official and release evidence must remain separate.

Only the adaptive classical mask gauge and its corresponding scan are changed.
The explicit Record follows open/compensate, exactly one full scan, and close.
The old quantum arithmetic, original masks and admission predicate are retained.
`DOMAIN_TRANSFER_ARGUMENT.md` states the phase identity, restoration contract
and pointwise no-T-loss argument. `WIDTH_COMPATIBILITY.md` distinguishes the
owned selector bits from the unchanged engine's implicit classical scratch.

The model is384003 static T (+11), Q889, and approximately383156.1974647618 mean T.
The exact improvement is the stored capped64 occupancy expectation, enclosed by
21.650726134792 and21.650726134793 T. It is encoded as a hexadecimal numerator
over a power of two; no huge decimal integer conversion or independence claim
for the correlated scan masks is used. These are source expectations, not
measured original-verifier results.

## Mandatory sequence

1. Corrected adaptive component smoke, then its full80-case gauge/scan gate.
   The existing original emitter stays byte-identical. The corrected v2 checker
   requires exact49462/49463 serialization, ownership and all original value,
   phase, mask and quantum restoration checks.
2. Independently reviewed source packet and component plan; root runs
   `prepare_component_gates.py` under the shared guard. It validates all eleven
   inherited gates plus the full adaptive gate. A smoke receipt cannot enable
   production emission.
3. Invoke the public `gen_dqi.py` directly for A; its own shared memory guard
   launches `build_v7.py`. Do not nest another lock-holding guard.
4. Stage the complete source/evidence closure, invoke its identical generator
   for B, then run `check_build_equality.py` under the shared guard. No old
   compiled tape is a portability/build dependency.
5. Apply the unchanged original source census to the actual loaded Python
   inventory; run every role in `JOINED_PANEL_PLAN.json`. All eight roles get
   fresh outputs, including the original complete corpus and special cases.
6. Freeze the one candidate identity before default,1,2,3 original salts.
   Run every salt at102400 shots, batch256, one worker, original confidence
   failure probability2^-128 and original hash-derived seeds. Do not select a
   favorable tape, salt or seed after observing errors.
7. Attribute all positive official errors with the unchanged exact original
   sampling tasks and original-worker confirmations. Compare actual T means
   with saved public v5; each price uses its own actual failure factor.
8. Only then qualify, write reports, stream/read back source and circuit ZIPs,
   record SHA-256s and save the complete delivery. A lower model is not banked.

All heavyweight execution belongs to root under the memory guard. On a memory
limit, preserve the completed work and split the job; do not retry unchanged.
This source packet launches no new population draw and authorizes no submission.
