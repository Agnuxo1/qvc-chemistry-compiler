# V5b admitted-domain transfer argument — source scope

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This argument addresses the selected changes from frozen v4. It is a
source-level correctness and ownership argument, not a new native receipt,
population estimate or official score. The full original proof, its exact
source-binding qualifications and the frozen census remain separate evidence.

## Unchanged input event and physical representation

The public input law, cutoff 15, unit conditions on active quadratic
numerator and denominator residues, constant-gcd half-core condition,
degree drops at most two and exclusions of simultaneous gap starts 17/15
and 14/12 are unchanged. The public syndrome map, query heads, fixed
squarefree padding, locator/preimage charts, finish geometry, weight gauge
and all 4,095 scan positions are the same as v4. No selected provider reads
a compiler-supplied terminal degree or profile.

These identities support transfer of the same admitted-event argument.
They do not transfer historical observed failures, official sample means,
failure factors or prices. A later v5b qualification must bind the exact
immutable 500-million-draw certificate and retain its ideal-IID/fixed-PRNG
interpretation, current-runtime NumPy CDF/grid ABI qualification and the
single TV allowance. No second TV addition or new adaptive census is made.

The historical source chain also retains the two documented exceptions in
the optimized-source binding addendum: the authorized pipeline replacement
and its exact AST/public-linear/runtime chain, and the documentary receipt
whose old bytes were not recovered. The latter must not be described as a
proved completion-fields-only edit. All other historical executable/source
bindings remain exact.

## Matched first-two inverse debts

The publicly initialized 24-bit carry equals one before the special
first-two charts. The unchanged generic reverse loop and tail close restore
that same constant before their returns. The special charts do not otherwise
read the carry. Their owner can therefore toggle its low bit to expose a
clean 24-bit bank, require each operation to reset it, and toggle it back
before generic work or final owner cleanup. The production adapter asserts
this constant-one contract. A separate full key gate observes both actual
carry seams and the initially zero rolling flag.

For a K24 source S, let N be its F4096 norm and h the six-bit quadratic norm
of N. The matched prefix implements inv0(S), while recording its actual
six-bit tower-basis HMR mask for h. Every other prefix debt is repaid and
the borrowed carry bank is cleared. Only the classical mask and its exact
source/owner record remain live across the intervening diagonal computation.

The matching return begins with inv0(S). The retained-norm inverse computes
the reciprocal of the six-bit norm of that input's F4096 norm. Field-norm
multiplicativity gives this value as h(S), including S=0 under inv0. Before
that value is reused, the provider converts it to the exact tower basis of
the saved mask, applies the mask's CZ correction, undoes the basis change
and frees the saved mask. It then completes the locally closed 195-T return,
including its own fresh scalar-mask cleanup. The source value and every
borrowed bit are restored, and the original first-two outer masks are paid
in their original order.

The retained child norm therefore supplies an exact later witness for the
deferred prefix debt. It is not a missing inverse-phase charge. The source
norm vanishes precisely when S vanishes, so the zero-safe norm identities
introduce no new nonzero-half or unit assumption. Native prefixes with an
open mask are correctly marked value-only; the matched pair must pass the
full phase and restoration checks. The three production returns retire
exactly the three records created by the three prefixes.

## Transpose at public capacity 14

The new core changes only its recursive window-module name. The window
changes that core import and the public transpose set from `{17}` to
`{17,14}`. The existing lower windows remain `{17,14}`. The four local modes
of the capacity-14 source window were already admitted by the accepted
lower tensor, and the simultaneous starts 14/12 were already excluded.
No additional half-core restriction is introduced.

The reused transpose tensor restores all source views and returns the exact
third-source zero predicate to the existing handoff interface. Adoption
repays the pending source/local masks before any source mutation and skips
only the duplicate query of the same witness. The two new handoffs occur at
capacity 12, alongside the existing two at capacity 15. All 32 local debts,
14 park/unpark cycles and two parked-scale payments remain explicit.
Temporary reciprocal debts merge into their restored reciprocal witnesses
and receive the existing Clifford corrections.

The full component gate keeps all 256 original preimage fixtures and adds
the same ten fixed profile supplements. Their six below-cutoff records
test only the independently admitted preimage interface; they remain
excluded whole-decoder inputs. Their four above-cutoff records remain
fully admitted. The isolated size-11 gate supplies all-four-mode coverage.
Those scopes are not a new probability experiment.

## Cubic20 and the 62-T quotient phase

The existing outer quadratic chart forms the F4096 denominator's GF64
norm N and relative numerator Z with the unchanged 42-term dual-number tensor. Its phase is
the absolute trace of Z times inv0(N). The new inner GF64 implementation
uses the existing cubic inverse scaffold but contracts the nine inverse
reassembly products directly with the live numerator's trace parities.
It does not first allocate an inverse output word. This computes the same
trace quotient and then erases the same scaffold with its exact witnesses.

The cubic inverse is zero-safe. In the outer zero-denominator case the norm
and relative numerator are both zero, so the same inv0 phase convention
continues to hold. Both outer six-bit outputs are measured and repaid with
the original tensor and square-linear mask corrections. The denominator,
numerator, public views and all scratch are restored. No new predicate,
zero exclusion, probabilistic branch or mask interpretation is introduced.

The paired caller keeps its existing exclusive mask branches: the main
nonzero-RHS-mask phase decreases from 63 to 62 T; the zero-RHS rare27 path
is unchanged. Eighteen calls therefore save `18*(1-2^-24)` expected T.
The exact event ledger replaces the 36/24 discount with 35/24 and preserves
the 27/0 and 27/36 terms. The helper lifetime increases from 18 to 22; the
current caller accommodates it at Q889, and a future width merge requires
a new lifetime proof as described in `WIDTH_COMPATIBILITY.md`.

## Evidence still required

The nine full component receipts, their normal guards and exact sources
must pass before a new tape can be emitted. Actual complete builds, a fresh
portable rebuild, circuit/source equality, the unchanged source census and
the original joined native panels are required for the complete composition.
Four fresh original official runs then determine actual measured means,
integer failures, factors and costs. Every positive-error salt requires
exact-draw attribution against the same frozen admitted event. No component
test or source expectation substitutes for those whole-candidate receipts.
