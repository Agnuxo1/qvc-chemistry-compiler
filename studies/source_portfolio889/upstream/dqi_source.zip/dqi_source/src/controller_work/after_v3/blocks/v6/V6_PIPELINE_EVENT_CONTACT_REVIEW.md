# V6 pipeline and event ownership: narrow source review

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

**Reviewed source:** `controller_work/after_v3/integration_v6/v6_pipeline.py`, SHA-256 `309c75ead9244c53e61fef9eaf8d1c6a0c1d2110de707a61ea75d54a342e0606`, and `v6_events.py`, SHA-256 `d44ff2142bd44ae685fd23184103d06cc75211ac4182aada01edada55eea646d`.

No source blocker was found in these two files. This review is limited to provider binding, the first-three physical lifecycle, inherited norm-stage accounting, and exact event arithmetic. It does not approve the still-separate component binder, build, portable source closure, full-decoder panels, population transfer or official runs. No project module was imported or executed by the reviewer. Bounded standard-library AST, source-hash and Fraction checks were used.

## Exact provider and debt ownership

The generic direct-return provider is bound before importing the first-three adapter, so the adapter captures the selected `Last` arithmetic through its immutable normalized base. The asserted identities tie `First3.Base`, `First3.Third.Base`, the captured base extractor and its actual rolling-tail owner together. `First3.Phase` and `Third.Norm` both use the matched retained-norm provider. Only `P.Extractor` selects the new first-three chart; the global closed-inverse binding to the old phase84 provider is retained honestly and is not redirected to an adapter with a public-carry promise.

The prefix requires six actual open matched records with 191-T prefix counts and six-bit child masks, plus the third-chart's separate one-bit zero-residue mask. Generic extraction begins at public index 3, with carry one and raw input at that index; it omits only that index's input scale. The inherited generic return restores that public carry before the rolling tail is closed. The special reverse charts then borrow the actual carry bank, pay the saved masks in their matching bases, return all owned bank bits to zero, and restore the public carry one. All six records close and the third zero flag retires. Arbitrary initial carry is explicitly outside this production-only contract.

The preimage retains the separately selected transpose14 provider and paired62 entry at both actual core and outer call sites. The paired62 helper count is explicitly 22, compared with the previous helper's 18; there is no untested width-merge claim. The joint source, projective finish, scan, local mask and tail bindings remain asserted.

## Norm-stage count

The reported 64 key stages and 114 total stages are correct in their expressly stated source-derived sense:

- Generic indices 3 through 34 supply 32 prefix stages.
- Their returns supply 31 ordinary stages and one retained-child 66-T stage, giving 32 return stages.
- The six matched special inverse calls use their own explicit 191/195-T stack and are not counted as old nested-66 stages.
- The 34 synthesis closing stages and 16 finite-finish closing stages add 50, giving 114 total.

The last-return stage has its own retained-child body, so 114 must not be relabeled as an instrumented count of literal calls to `inverse_twelve_deferred`. The source labels make that distinction. These historical-stage counts create no extra three-T discount; all actual savings are already in the changed complete providers.

## Exact event reconciliation

The key-only multiset agrees with completed component report `923df5eb0f79f2090f012cc5286267c1de5b3444177516658c4901fd348f9cb4`: 32 selected-target 84/24 events, 66 inverse 27/12 events, one last-return 15/6 event, seven scalar 4/6 events, one gauge 10/1 event, and 21 zero-predicate 22/1 events. The six new return masks are observed by the already-installed scalar wrapper. The prefix's saved zero predicate and matched child masks are paid by CZ and do not create duplicate conditional discounts.

For the full source model, the 16 finite closing events raise the ordinary inverse27 count to 82. The actual converter adds 18 converter inverse27 events, 16 converter zero-predicate events, two parked-scale 23/12 events and the complete 18 paired62 event triples. The new hook rejects the old paired event labels. At 4,025 active physical scan positions the scan contributes exactly one 11×4025/4096 discount term.

An independent Fraction sum of those declared events gives:

| Quantity | Exact value |
| --- | --- |
| Full static T | 383,992 |
| Source mean | `13165890612252429/34359738368` = 383177.84819089656 |
| Static saving from v5b | 55 |
| Source-mean saving from v5b | `277582827/4194304` = 66.18090319633484 |
| Key static T / prefix T | 216,928 / 101,087 |
| Required physical maximum | Q889 |

These are source counts and a uniform-fresh-mask expectation, not an official measured mean or score. The passed first-three component is necessary evidence but does not replace complete joined, physical rare-case and four-salt qualification under the new whole tape.
