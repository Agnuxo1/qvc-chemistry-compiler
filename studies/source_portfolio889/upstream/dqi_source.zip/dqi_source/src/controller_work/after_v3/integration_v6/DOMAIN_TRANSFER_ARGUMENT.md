# V6 admitted-domain transfer argument

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This argument concerns the separately composed `integration_v6` source, planned for public release v5. It does not report a full native build, joined-decoder test, new population census or official verifier result. The frozen v5b packet and its prior transfer argument remain unchanged. Every v5b arithmetic provider, public window and admission condition is retained; the only added value-chart change is the repaired third public pivot.

## Original event retained

The declared admitted event is still cutoff j≥15; all active finite numerator and denominator residues nonzero; and the original full degree35 half-core chart with constant gcd, degree drops at most two and the existing excluded paired gap starts `{17,15}` and `{14,12}`. The public places, padding, original syndrome law, masks, error magnitudes, terminal policy and scan support are unchanged. No new input-dependent compiler parameter or classifier branch is introduced.

Because j≥15, the third extraction pivot is active on every admitted input. Its original numerator and denominator are therefore units. This is the exact existing promise used below. A raw residue at that point may nevertheless be zero, so the replacement explicitly handles that case rather than excluding it.

## Repaired chart

Let Y be the raw extension-field residue at index2. Let A and B be the evaluations of the two preceding coefficient heads at that public node, and let a=20 and b=18 be the fixed differences of the quadratic constants. The ordinary two query steps, with incoming carry1, produce

`D2=(1+A*Y)/a` and `N2=(Y+B*D2)/b`.

The old admitted condition implies `1+A*Y != 0` and `a*Y+B*(1+A*Y) != 0`. The new chart computes the actual quantum predicate z=[Y=0] and uses the zero-extended inverse chain

`u=inv0(inv0(Y)+(1+z)*A)` and `P2=b*inv0(a*u+B)`.

For Y nonzero, ordinary field algebra gives `u=Y/(1+A*Y)`. For Y zero, the controlled correction suppresses the A addition and gives the same value u=0. The final inverse argument is nonzero by the old N2 condition, and the result is exactly D2/N2. The source does not assume raw Y is a unit and adds no rejected event. The component also checks the valid zero-cross-coefficient cases; it is not restricted to a generic rational chart.

The first two heads are unchanged. Generic extraction starts at index3 with carry1 and the raw third-following residue. Every later queried pair is the old pair multiplied by a common nonzero carry ratio. Inductively all later heads and real zero predicates are unchanged. The public tail flags, terminal seed parity, squarefree padding and synthesized degree35 chart therefore describe the same physical input.

## Boundary scale and preimage

The different common carry generally changes the final base-field scale and can change which carry coordinate supplies the selected unit. `blocks/v6/boundary_scale_first3.py` independently checks the first three heads, all later heads and flags, the new carry and the selected coordinate against the original physical boundary oracle. It rescales both original N and D by `selected_new/selected_old`, a nonzero element of F4096, and verifies the corresponding gamma against the unchanged terminal unit.

The monic padded locator and hence its Euclidean degree profile are unchanged under this common scaling. The even/odd half-source polynomials scale by the same square root, so constant gcd and every original gap condition are invariant. The inherited projective preimage/finish contract cancels the common scale in the physical phase. The original physical phase oracle remains the full-decoder authority; a key-only boundary test does not replace that check.

A previous gauge-one label is not a proof of gauge-one coverage under this new scale. The actual783-case report identifies a new gauge-one member of the original corpus, with carry `(0,2229)`. The old rare physical case is still retained as a regression input. The joined workflow separately checks the actual new gauge-one input and the admitted raw-zero construction through the full scan.

## Matched phase ownership

The prefix borrows the production constant-one24-bit carry as a clean bank by the existing public X convention. The first two charts use three matched191/195 inverse pairs and the third chart uses another three. Each prefix retains its actual six-bit tower-norm HMR mask. Its matching return reconstructs the exact original child norm and pays that actual mask before changing the witness. No mask is relabelled or replaced with a presumed zero outcome.

The third chart additionally borrows the tail controller's initially zero predicate. After its controlled addition it HMR-resets that physical bit, keeps the actual one-bit mask and leaves the allocation owned by the tail. At the matching return, after the generic tail has closed, the inverse chain exposes `u=Y/(1+A*Y)`. Since zero(u)=zero(Y), the newly computed return predicate is the exact witness for the prefix mask; one CZ pays it. The remaining inverse steps restore raw Y. The fresh return predicate is then HMR-erased and its actual mask is paid by the unchanged22T conditional zero phase on that restored Y.

There are36 saved inverse-mask bits plus one saved zero-predicate bit. They are classical storage, not37 new quantum helpers. The prefix restores carry1 before generic index3 and resets the borrowed tail bit without freeing it. The return runs after the tail owner has released that flag, uses one fresh predicate plus24 inverse helpers beside864 retained bits, and restores carry1 before the original owner frees it. These are the Q889 lifetime boundaries required by the new component and whole-source checks.

## Exact count interpretation

The replaced ordinary third-pivot work costs1329 static T, with discounts27/4096 and84/2^24. The explicit replacement costs1274 static T:620 prefix and654 return, including both23T zero queries, both24T controlled additions, three191T prefixes, three195T returns, and the22T fresh predicate phase. Its discount is12/64+11. Thus the exact expected saving is

`55 + 12/64 + 11 - 27/4096 - 84/2^24 = 277582827/4194304`.

The full key event Counter is32 direct84/24 events,66 inverse27/12 events, one15/6 last-return event, seven4/6 scalar events, one10/1 gauge event and21 events of22/1. The inherited full preimage and scan events are unchanged from v5b. The new prefix's saved zero mask is paid by a zero-T CZ and contributes no additional conditional discount.

The64 key/114 total norm-stage counts are a source-derived description:32 generic prefixes,31 ordinary returns and one retained-child return, plus34 synthesis and16 finite finish stages. They are not114 literal calls to the old66T function and do not create another3T-per-stage credit. All cost changes are already included in the explicit ledger above.

## Evidence and release limits

The full isolated third-chart receipt checks20480 cases with raw zeros and zero cross coefficients, two builds and three HMR seeds. The complete physical key receipt checks783 cases, both real carry boundaries, all six matched debts and the predicate debt, with the old76 exclusions retained. These are bounded native component checks, separate from the algebraic argument.

The selected source must also pass all nine inherited v5b component gates, a fresh full build and byte/source-identical portable rebuild, all eight joined roles, and the original source census. Four fresh full original verifier salts and exact attribution of every observed value/phase error are required before reporting a new released T gain or price.

If that selected-source and same-admission chain is qualified, the immutable500million population certificate applies to the same declared event; there is no resampling or new event estimate. The original certificate's confidence, fixed-PRNG/IID model and current-runtime CDF/grid qualifications remain intact, with its TV allowance added once. It is separate from observed official integer failure pricing. The historical documentary mismatch and authorized old pipeline transfer remain exactly as recorded in the existing optimized-source-binding addendum; no missing old bytes or stronger documentary equivalence are asserted here.
