# V5 admitted-domain transfer argument — source scope

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

This argument addresses the two selected changes relative to frozen v4.
It is not a native test receipt, a new population certificate, an official
score or a universal machine-checked circuit proof. The new binding requires
actual full component gates before emission; joined native gates and four
new original official salts remain separate.

## Preserved physical event and representation

The public input law, cutoff 15, active quadratic numerator/denominator unit
conditions, constant-gcd half-core condition, degree drops at most two and
existing exclusions of simultaneous gap starts 17/15 and 14/12 remain
unchanged. The public syndrome chart, query heads, squarefree padding,
source/finish geometry and all 4,095 scan positions are the same as v4.
Neither new provider reads a compiler-supplied degree or profile.

V4's source proof, historical binding addendum and immutable population
certificate are provenance dependencies. A later v5 release must bind the
same exact certificate and retain its source-proof, ideal-IID/fixed-PRNG,
current-runtime CDF/grid ABI and once-only TV qualifications. This source
file does not independently certify or change that statistical statement.

## Production carry and the three inverse charts

The unchanged key prefix allocates the 24-bit carry as zero and publicly
sets its low bit, so its initial field value is one. The unchanged generic
reverse query loop and tail close restore that exact original value before
the first-two return charts. No first-two chart reads the carry, and its
owner resets/frees the register only after those three charts return.

The selected production adapter therefore uses a public low-bit toggle to
obtain a clean, owned 24-bit bank. Each retained-norm inverse returns every
bank bit to zero. A second public toggle restores the original carry value
before the unchanged owner acts. This is a lifetime fact about this public
producer/consumer pair, not permission to reinterpret an arbitrary quantum
carry as clean. The adapter record explicitly requires the production
constant-one contract. A separate native seam panel observes all 24 bits
at the actual return boundary.

For a K24 source S, the provider computes its F4096 norm N, retains the
six-bit norm h of N and its reciprocal gamma, and reconstructs inv0(N).
The two old source-half masks are paid using retained original N. The
original-N HMR mask is paid from inv0(N) and retained h in its exact tower
chart. The child-h mask is paid from gamma by the existing scalar phase,
then gamma and inv0(N) are erased from the appropriate restored norms.
Each witness remains live until its debt is paid. The field-norm identity
N=0 iff S=0 makes the same inv0 algebra valid on zero, so no new unit or
nonzero-half condition is introduced.

The three replacements implement the same locally closed inverse value
and phase maps as v4. The original first-two deferred masks and public
coordinate transforms retain their exact order. Prefix operations and the
generic return for indices at least two are unchanged. The arbitrary-unit
carry extension of the old isolated component remains a distinct interface;
it is neither used nor claimed by this production-only adapter.

## Additional transpose at public capacity 14

The new core differs from the frozen handoff core only in its recursive
window-module name. The new window differs only in that core import and
the public transpose set, now `{17,14}`. The existing lower windows remain
`{17,14}`. Capacity 14 therefore uses the same three-source window and the
same four allowed local modes that its existing lower tensor already uses.
The potentially excluded simultaneous starts 14/12 were already outside
the admitted half-core event; no additional joint-gap restriction is used.

The reused transpose tensor receives the same evaluated source views and
returns its last live zero predicate on the exact third source witness.
`Step.adopt` performs the existing local/source mask repayments before any
later source mutation and skips only the immediately duplicate zero query.
The two additional handoffs are at capacity 12; the existing two are at
capacity 15. Every local still occurs once in each half, all 32 local masks
are retired, and the gauge carrier retains 14 park/unpark pairs and two
parked-scale payments. Additional compact reciprocal debts merge into the
existing exact reciprocal witness and are paid by Clifford correction;
they do not require an uncharged inverse-phase oracle.

The full caller must test the old fixture set plus explicitly labelled
component-domain cases exercising the additional modes. Cases below cutoff
15 may be used to test the half-core interface when its own conditions hold;
they do not become admitted whole-decoder inputs. The isolated size-11
transpose gate separately covers all four modes. Those scopes remain
distinct from a new population experiment.

## Required evidence before a result is claimed

Source equivalence and ownership support transfer of the unchanged admitted
event, conditional on the original argument. A completed new component
manifest, actual loaded-source inventory, two identical full builds,
unchanged full native panels and fresh original official results are still
required. Observed excluded-case behavior may differ; no historical excluded
error count, official failure factor, sample mean or score is inherited.
