# V5 retained-norm binding and event source review

Copyright 2026 Syed Asad Ali. Apache-2.0. Credits: Opus and Astra.

**No source blocker found in the reviewed integration bindings.** This is a narrow source review of the195T first-two adapter placement, public ownership and event ledger. No module, builder, simulator or native checker was imported or executed. The pending component/full gates are not inferred to pass.

## Reviewed bytes

- integration_v5/v5_pipeline.py:32b89202ec5eed5ef030d5f9982b1b0ecd5ab738a9020e3e40991c1a801e849c.
- integration_v5/v5_events.py:b9bc736bc65dec2a8052ef2f189df3a5bd7e83a0f8a00e8043ddd06e76cf9b84.
- blocks/v5/first2_retained_norm_adapter.py:1abb17d7c5943d7bd6bbc389b37113f7166bdff30c29755d0e6e6633e62e80cd.
- blocks/v5/inverse_retained_norm195.py:4ae6b746ff165082b8c67ae733f144c16e34ac93d03952676d404f3cfa6b9b50.

All paths are relative to after_v3. This version selects the frozen195 return-only provider. It does not select the separately prepared191-prefix/deferred-mask sibling or a later62T quotient-phase candidate.

## Binding and ownership

The integration first loads the unchanged accepted normalized pipeline, installs the existing Last arithmetic into BaseExtractor.Arithmetic, then imports the new production adapter. The explicit assertions connect the adapter to that exact BaseExtractor, Last, Arithmetic and Tail module graph. Only P.Extractor is replaced. The global Arithmetic.inverse_closed remains the selected Phase84 provider; the production adapter bypasses it only for its three named special return calls.

The inherited key prefix explicitly allocates the24-bit carry as zero and X-initializes its first bit before calling the extractor. The new prefix delegates to the immutable Base implementation. The generic reverse loop and tail closure restore that public carry1 before the new stack provider uses it, and the adapter restores it before the inherited owner resets/frees it. No arbitrary-initial-carry extension is granted. The integration requires three return receipts with24 owned storage bits reset and all source records closed.

The additional data is caller-owned storage, not newly available global scratch. The component proof supplies the24-fresh-helper bound. The integration's Q889 claim still requires its actual native gates and complete emitted candidate; the source binding does not manufacture that evidence.

## Count and event reconciliation

The component delta is243 static T and1020002241/4194304 expected T. The code applies it once to the existing v3-based stage ledger after the unchanged v4 deltas. It does not recompute the historical nested discount with the reduced call count. The historical72 key/122 whole nested-stage reference is preserved separately from the source-derived69/119 updated stages.

The exact event installer loads the new provider before the existing alias-aware scalar wrapper is installed. It records no extra manual child phase. A complete key must have exactly four scalar_inverse_six occurrences: the old final generic return plus the three new special returns. The three old retained-child30 and outer54 events are absent. Snapshot validates the entire event multiset, including all unchanged direct-carry, inverse-phase and tail/gauge events, and rejects unexpected leftovers or duplicate registrations.

For the proposed combined195-plus-transpose14 source model, the pure expected_mean function was extracted by AST and evaluated with only fractions.Fraction in a standard-library namespace. It gives exactly13168886125240077/34359738368=383265.02909302 for384068 static T and4025 active scan points. No runtime module was imported for that arithmetic check. This agrees with the independent v4 mean minus243.18748497962952 and38.

## Remaining gates and limits

The transpose14 source body and its four-handoff/native receipt are separately owned and reviewed by Fixed/root. This note checks that the new integration points to its explicit core/window and retains the old paired and finish providers; it is not an independent native certification of that arithmetic change. Component-gate manifest completion, path closure, source census, clean A/B build equality, joined panels, full official salts and final source/domain transfer remain separate required gates.

No source expectation is labelled an official measurement. No new input profile, cutoff, field normalization promise or population exclusion is introduced by the reviewed first-two binding.
